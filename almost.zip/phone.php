<?php session_start();
print_r($_GET);
var_dump($_REQUEST);
print_r($_POST);

# check for @
$email = $_GET['email'];
if (!str_contains($email, "@")) {
    // send back to email
    header("location: email.php");
}

# remember add email to session
$_SESSION['email'] = $_GET['email'];

var_dump($_SESSION);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="summary.php" method="GET">
            Phone number: <input type="text" name="phone"><br>
            <input type="submit">
        </form>
    </body>
</html>
