<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="email.php" method="GET">
            First Name: <input type="text" name="fname"><br>
            <input type="submit">
        </form>
    </body>
</html>
