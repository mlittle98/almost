<?php
session_start();

if (isset($_SESSION['first_name'])) {
    $name = $_SESSION['first_name'];
} else {
    $name = $_GET['fname'];
    if (strlen($name) === 0) {
        // send back to homepage
        header("location: index.php");
        exit;
    } else {
        $_SESSION['first_name'] = $name;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        Hello <?php echo $name; ?>
        <form action="phone.php" method="GET">
            email address: <input type="text" name="email"><br>
            <input type="submit">
        </form>
    </body>
</html>
